const typeColor = {
    bug: "#26de81",
    dragon: "#ffeaa7",
    electric: "#fed330",
    fairy: "#FF0069",
    fighting: "#30336b",
    fire: "#f0932b",
    flying: "#81ecec",
    grass: "#00b894",
    ground: "#EFB549",
    ghost: "#a55eea",
    ice: "#74b9ff",
    normal: "#95afc0",
    poison: "#6c5ce7",
    psychic: "#a29bfe",
    rock: "#2d3436",
    water: "#0190FF",
  };
  let globalValue = []


  
  

  const baseUrl = " https://pokeapi.co/api/v2/pokemon/";
  const card = document.getElementById("change[index]");
  const btn = document.getElementById("btn");
  let getPokeData = () => {

    let id = Math.floor(Math.random() * 150) + 1;

    const finalUrl = baseUrl + id;

    fetch(finalUrl)
      .then((response) => response.json())
      .then((data) => {
        generateCard(data);
      });
  };

  // <--------Card index degisimi---------------------------------------------->
  let index = 0
  function firstButton(){
    index++
    if(index==2){
        index=0
        // document.getElementById("btn").disabled = true; //Button inactive
    }
  }
  let change = [card1,card2]
  


  let generateCard = (data) => {

    const hp = data.stats[0].base_stat;
    const imgSrc = data.sprites.other.dream_world.front_default;
    const pokeName = data.name[0].toUpperCase() + data.name.slice(1);
    const statAttack = data.stats[1].base_stat;
    const statDefense = data.stats[2].base_stat;
    const statSpeed = data.stats[5].base_stat;
    const themeColor = typeColor[data.types[0].type.name];
    

        change[index].innerHTML = `
          <p class="hp">
            <span>HP</span>
              ${hp}
          </p>
          <img src=${imgSrc} />
          <h2 class="poke-name">${pokeName}</h2>
          <div class="types">
          </div>
          <div class="stats">
            <div>
              <h3>${statAttack}</h3>
              <p>Attack</p>
            </div>
            <div>
              <h3>${statDefense}</h3>
              <p>Defense</p>
            </div>
            <div>
              <h3>${statSpeed}</h3>
              <p>Speed</p>
            </div>
          </div>
    `;
    let power = statAttack*statSpeed/200;
    let health = hp+statDefense;


    const temporaryMemory = {
      power : power,
      health : health,
      pokeName: pokeName,
      imgSrc:imgSrc
    } 
    globalValue[index]=temporaryMemory;

    // localStorage.setItem('temporaryMemory', JSON.stringify(temporaryMemory));
    // console.log(localStorage.getItem('temporaryMemory'))
        
    appendTypes(data.types);
    styleCard(themeColor);

    // console.log(globalValue)
    // console.log(power.length)

  };
  let appendTypes = (types) => {
    types.forEach((item) => {
      let span = document.createElement("SPAN");
      span.textContent = item.type.name;
      document.querySelectorAll(".types")[index].appendChild(span);
    });
  };
  let styleCard = (color) => {
    change[index].style.background = `radial-gradient(circle at 50% 0%, ${color}, #ffffff)`;
    change[index].querySelectorAll(".types span").forEach((typeColor) => {
      typeColor.style.backgroundColor = color;
    });
  };
  btn.addEventListener("click", getPokeData);
  window.addEventListener("load", getPokeData);



function attack(){
    document.getElementById("btn").disabled = true;
    let i = 0;
    while (i < 10) {
      // console.log(i)
      console.log("Tur --- "+(i+1)+" --- Sonu")
      console.log("Defense Life=> "+globalValue[0].health)
      console.log("Saldıran Canı=> "+globalValue[1].health)

      globalValue[0].health -= globalValue[1].power
      globalValue[1].health -= globalValue[0].power

      if(globalValue[0].health<=0){
        i=10;
        console.log(globalValue[1].pokeName+" Won !..")
        lost(0);
        winner(1);
      }else if(globalValue[1].health<=0){
        i=10;
        console.log(globalValue[0].pokeName+" Won !..")
        lost(1);
        winner(1);
      }
      i++;
      
    }
        // globalValue.splice(0,globalValue.length); //listeyi boşalt
        
}

function lost(value){
  change[value].innerHTML =`
  <img style="filter: grayscale(100%);" src="/img/epic-fail.png">
  </br>
  <img style="filter: grayscale(100%);" src=" ${globalValue[value].imgSrc}">
  </br>
  <h1 class="poke-name">${globalValue[value].pokeName}</h1>
  `  
}
function winner(value){
  change[value].innerHTML =`
  <img src="/img/winner.png">
  </br>
  <img src=" ${globalValue[value].imgSrc}">
  </br>
  <h1 class="poke-name">${globalValue[value].pokeName}</h1>
  `  
}
